
ROMPATCHER+ v2.6
http://www.symbian-toys.com/RomPatcherPlus.aspx

HOW TO INTEGRATE RP+ IN THE ROFS:
 - To integrate properly RP+ in the ROFS you only need to add a modded Starter*.rsc to the \Resource\
 - The modded Starter*.rsc file must launch RomPatcherAuto.exe

FURTHER NOTES: 
 - Don't mess-up with RP+ files and filenames.
 - Don't place the RPPlus.dat file in the cooked fw for AutoStarting patches, it will not work!
 - If you want to distribuite additional patches, you don't need to use the scriptinit stuff, you can just add them to the \System\Data\RP_Patches.zip and RP+ will do the work for you.
