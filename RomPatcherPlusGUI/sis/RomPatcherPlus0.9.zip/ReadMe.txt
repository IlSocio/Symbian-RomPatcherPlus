
ROMPATCHER+ 0.9 BETA


*** How to install ***
There are 3 different ways to install RomPatcher+
1) If your phone has been hacked to allow installation of unsigned .sis then install RomPatcherPlus0.9.sis
2) If your phone has been hacked and has the Leftup root ca, then sign the RomPatcherPlus0.9.sis using the Leftup certificate and install it.
3) Otherwise, you can sign and install the "Lite Version", using a DevCert or OpenSigned Online. But, in this case, you MUST also manually copy the patcher.ldd in c:\sys\bin\ folder


*** Patcher.ldd Not Found Error *** 
If you launch RP+ immediately after it has been installed you could get the "patcher.ldd not found" error.
Just reboot the device and launch again RP+


*** Change-Log BETA 0.9 ***
+ Fixed: was not compatible with some devices (eg. E63). The error message "patcher.ldd not found" was shown always also after a reboot.
+ Fixed: some patches were not applied due to additional spaces in the .rmp... Now additional spaces should be handled correcly.
+ Fixed: crash when trying to patch an executable that was missing in the device.
+ Improved: better parsing of the patch file. Both windows and unix text should be handled properly, with  unicode/utf8/ascii encoding.
+ New: added LoadPatch/CheckPatch/ApplyPatch logs to the Engine, to check the correct patch parsing... <-- I know these popups are really annoying, but in order to release the final verion I need to be sure that (almost) ALL the RP patches will work correctly on RP+ also.
+ Removed: autostart correctly works, so popups have been removed (however, other popups have been added to the Engine, so you'll see popups for each patch you put in autostart)


*** Final Release and other stuff ***
The final release will be freely available on 29August at the page below:
http://www.symbian-toys.com/rompatcherplus.aspx

Due to my limited spare time, I have to figure out and in the shortest time possible, if it worth to invest further time to improve RomPatcher+ or if it is better for me to spend time on other activities, so I'll proceed in this way:
- on 29 August I'll publicly release the first final version of RomPatcher+
- starting from today up to 6 September will be possible to make donations through the offical website.
- on 7 September I'll decide if continue to develop and improve RomPatcher+ or if suspend it definitely, this will depends on the donations received.
- if the project will continue, a new RomPatcher+ version with exciting new features will be release on 13 September. :)
- if it will be suspended, will not be released any new version. :(

In short words, if you like this software and you want me to keep spending time on it, then support it. ;)

Regards,
Marco.



Thanks to:
- ZoRn for the original RomPatcher idea.
- FCA00000 for its brilliant brain.
- wadowice, templove, bugb, abgnokia, leftup and others, for their contribution to the underground Symbian scene, keep up with the good job!
- megaexer for svg icon.
- All the Beta-Testers of Symbian-Freak.com and Nokioteca.net forums.
