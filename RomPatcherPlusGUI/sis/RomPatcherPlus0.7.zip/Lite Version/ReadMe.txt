
After you've installed the "Lite Version" you MUST copy the patcher.ldd file inside the c:\sys\bin\ directory.
