

ROMPATCHER+ v2.0 - FINAL VERSION
The version jumped to v2.0 to make more clear to newbies too that this is an improved version of the RomPatcher by ZoRn.


*** How to install ***
There are 3 different ways to install RomPatcher+
1) If your phone has been hacked to allow installation of unsigned .sis then install RomPatcherPlus2.sis
2) If your phone has been hacked and has the Leftup root ca, then sign the RomPatcherPlus2.sis using the Leftup certificate and install it.
3) Otherwise, you can sign and install the "Lite Version", using a DevCert or OpenSigned Online. But, in this case, you MUST also manually copy BOTH the files patcher.ldd and patchershadow.ldd in c:\sys\bin\ folder


*** Patcher.ldd Not Found Error *** 
If you launch RP+ immediately after it has been installed you could get the "patcher.ldd not found" error.
Just reboot the device and launch again RP+


*** Upgrade Error *** 
If you installed any previous beta version and you got this error when installing final version, please delete both e:\patches\open4all.rmp and e:\patches\open4all_n96.rmp and try again.


*** Change-Log v2.0 *** 
+ Fixed: The message "Application not compatible with the phone" is not shown anymore.
+ Fixed: Replaced the Open4All_N96 templove's version with wadowice's version.
+ Fixed: Sometimes the green\red patch icon wasn't showed properly
+ Improved: Touch Support, the tap will select the patch, a tap on a selected patch will apply/remove it
+ Improved: Patches can be placed in any drive, RP+ will follow the order Z: -> A: and will use the first drive which contain the \patches\ folder
+ Improved: Error messages will report the patch's name also.
+ New: Popup when launching RP+ to remember to everyone the 6th September deadline.
+ New: ApplyAll/RemoveAll options to quicly Apply/Remove all the patches.
+ New: Donate options menu...
+ Removed: Apply/Remove options have been removed because redundant. Just click on a patch to apply/remove it.
+ Removed: The annoying popups for apply patch have gone :) yeppi!!! 
+ Removed: The advanced menu' has been temporary removed, it will came back again with more options available like "Dump/View any user choosen area of memory"...


*** Other Important Stuff ***
Feel free to post RP+ v2.0 on forums or everywhere you like, I want just kindly ask you to include the warning message below which is important for the survivor of the project:

[quote]
Warning: If you like this software then support RP+ with a donation, otherwise its development will be definitely suspended on 7th September.
http://www.symbian-toys.com/rompatcherplus.aspx
[/quote]


Regards,
Marco.



Thanks to:
- ZoRn for the original RomPatcher idea.
- FCA00000 for its brilliant brain.
- wadowice, templove, bugb, abgnokia, leftup and others, for their contribution to the underground Symbian scene, keep up with the good job!
- megaexer for svg icon.
- All the Beta-Testers of Symbian-Freak.com and Nokioteca.net forums.
