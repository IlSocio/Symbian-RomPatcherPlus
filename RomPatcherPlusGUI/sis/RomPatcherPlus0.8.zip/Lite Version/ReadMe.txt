
After you've installed the "Lite Version" you MUST copy the patcher.ldd file inside the c:\sys\bin\ directory.

Check out the official website for the final release:
http://www.symbian-toys.com/rompatcherplus.aspx
