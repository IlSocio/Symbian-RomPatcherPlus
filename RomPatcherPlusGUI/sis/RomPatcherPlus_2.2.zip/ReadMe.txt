

ROMPATCHER+ v2.2 - FINAL VERSION


RomPatcher+ is an improved and fixed version of the RomPatcher software developed by ZoRn.
Using RomPatcher+ it is possibile to reach a new level of customization for you Symbian phone.

This is the list of the main differences in comparison with RomPatcher by ZoRn:
- New: it is now possible to apply/remove patches with just 1 click.
- New: added vertical scrollbar.
- New: introduced the new command "+SuperPage" which allow to patch the RAM area where is stored the SuperPage.
- New: introduced support for a new commands, info: return: error: check the demo1-4.rmp patches included.
- New: introduced #ifdef, #ifndef, #else, #endif, #define statements. This will allow to retrieve system values at runtime to create more flexible and powerful patches. Check the ReadMe_Macros.txt for all the details.
- New: you can search / filter the patches in the list. Just start typing the patch name to apply the filter.
- New: wildcard ?? support for patches.
- Fixed: Kern-Exec0 error when closing RomPatcher after a patch was applied.
- Fixed: doesn't unexpectedly crash when using large and complex patches.
- Fixed: RP+ can correcly patch contiguous shadow ram pages without any crash.
- Improved: the shadow ram memory is now fully released when a patch is removed.
- Improved: better compatibility (supports also the OmniaHD, 5630, E52 and probably future devices).
- Improved: the "Patch Info..." option shows all the information lines contained in the patch.



*** How to install ***
There are 3 different ways to install RomPatcher+
1) If your phone has been hacked to allow installation of unsigned .sis then install RomPatcherPlus_2.2.sis
2) If your phone has been hacked and has the Leftup root CA, then just install the RomPatcherPlus_2.2.sisx
3) Otherwise, you can sign and install the "Lite Version", using a DevCert or OpenSigned Online. But, in this case, you MUST also manually copy BOTH the files patcher.ldd and patchershadow.ldd in c:\sys\bin\ folder



*** Patcher.ldd Not Found Error *** 
If you launch RP+ immediately after it has been installed you could get the "patcher.ldd not found" error.
Just reboot the device and launch again RP+



*** Change-Log v2.1 > v2.2 *** 
+ New: it is now possible to search / filter the patches in the list. Just start typing the patch name to apply the filter.
+ New: the wildcard "??" is now available for patch-makers.
eg. SnR:sys\bin\installserver.exe:0011????02233043:0028??E00B20C043
(NOTE: 3rd byte will be kept unchanged)
+ Improved: changed installer to place Open4All_RP+ patch in the proper drive.
+ Fixed: in the SnR command, only the first instance was patched successfully. Wasn't possible to patch further instances of the same byte pattern.
+ Fixed: memory corruption when the patch contains 2 or more changes to a RAM memory address (not in the ROM range) and the "apply patch" fails.
+ Fixed: red-icon is shown like in RP by ZoRN, ie. if the patch doesn't perform any change to the memory the red-icon will be shown (eg. when a patch contains only comments or unmatched SnR lines)




*** Other Important Stuff ***
Feel free to post RP+ v2.2 on forums or everywhere you like, I want just kindly ask you to include the warning message below which is important for the survivor of the project:

[quote]
Warning: If you like this software then support RP+ with a donation.
http://www.symbian-toys.com/rompatcherplus.aspx
[/quote]


Regards,
Marco.



Thanks to:
- ZoRn for the original RomPatcher idea.
- FCA00000 for its brilliant brain.
- wadowice, templove, bugb, abgnokia, leftup and others, for their contribution to the underground Symbian scene, keep up with the good job!
- megaexer for svg icon.
- All the Beta-Testers of Symbian-Freak.com and Nokioteca.net forums.
