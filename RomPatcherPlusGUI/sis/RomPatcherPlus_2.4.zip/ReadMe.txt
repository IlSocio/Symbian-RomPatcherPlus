

ROMPATCHER+ v2.4 - FINAL VERSION


RomPatcher+ is an improved and fixed version of the RomPatcher software developed by ZoRn.
Using RomPatcher+ it is possibile to reach a new level of customization for you Symbian phone.

This is the list of the main differences in comparison with RomPatcher by ZoRn:
- New: can dump the whole rom content to file \romdumpplus.dmp
- New: can dump the SuperPage content to file \superpage.dmp
- New: full support for DomainSrv.exe autostart 
- New: introduced new commands ord_rel, ord_snr which allow to patch DLL using ordinal
- New: can be integrated in cooked ROM firmware
- New: it is now possible to apply/remove patches with just 1 click.
- New: added vertical scrollbar.
- New: introduced the new command "+SuperPage" which allow to patch the RAM area where is stored the SuperPage.
- New: introduced support for a new commands, info: return: error: check the demo1-4.rmp patches included.
- New: introduced #ifdef, #ifndef, #else, #endif, #define statements. This will allow to retrieve system values at runtime to create more flexible and powerful patches. Check the ReadMe_Macros.txt for all the details.
- New: you can search / filter the patches in the list. Just start typing the patch name to apply the filter.
- New: wildcard ?? support for patches.
- New: RP+ can be included in cooked ROM firmware
- Fixed: Kern-Exec0 error when closing RomPatcher after a patch was applied.
- Fixed: doesn't unexpectedly crash when using large and complex patches.
- Fixed: RP+ can correcly patch contiguous shadow ram pages without any crash.
- Improved: better compatibility (supports also the OmniaHD, 5630, E52 and probably future devices).
- Improved: the "Patch Info..." option shows all the information lines contained in the patch.



*** How to install ***
There are 2 different ways to install RomPatcher+ on your device:
1) If your phone has been already hacked to allow installation of unsigned .sis then install RomPatcherPlus_2.4.sis
2) If your phone has not been hacked yet, you can create and flash a cooked fw following the steps below:
- Download all the original fw files using NaviFirm+ - http://www.symabian-toys.com/NaviFirm.aspx
- Open the UDA fw file using NokiaCooker - http://www.symabian-toys.com/NokiaCooker.aspx
- Insert the patcher.ldd and patcherShadow.ldd files in c:\sys\bin\ and press the Save button.
- Use Phoenix or JAF to flash the modded fw on your phone.
- Eventually, use your DevCert or OpenSigned online to sign and install the RomPatcherPlus_2.4_LiteVersion.sis



*** Patcher.ldd Not Found Error *** 
If you launch RP+ immediately after it has been installed you could get the "patcher.ldd not found" error.
Just reboot the device and launch again RP+



*** Change-Log v2.3 > v2.4 *** 
+ New: Add to Auto (DomainSrv). You can now choose to start some patches using DomainSrv and some others using the standard way. 
+ New: Fault-Recovery. When the phone is turned on and it crashes due to some bugged patch setted as "Auto", then all the "Auto" patches will be temporary disabled, so you'll be able to turn on the phone and remove the bugged patch.
+ New: Donate by SMS option. Select this to make a donation to support RP+
+ New: Two powerful new commands available for patch makers (ord_rel, ord_snr). I strongly suggest you to use them when you patch some dll.
 ord_snr : ordinal (decimal value) : filename : original value : new value
 ord_rel : ordinal (decimal value) : filename : offset (starting from ordinal): original value : new value
 ord_snr:1:sys\bin\securitymanager.dll:AABBCC:AABBCC		; Apply the patch to the first export
 ord_rel:1:sys\bin\securitymanager.dll:0A:AABBCC:AABBCC	; Apply the patch to the first export+0x0A
+ New: Advanced > Dump ROM. Dumps the whole ROM content to file \romdumpplus.dmp
+ New: Advanced > Dump SuperPage. Dumps the superpage area to file \superpage.dmp
+ Improved: Popup will appears only once in a while (But don't forget that the development of RP+ needs to be supported)
+ Improved: Patches .zip archive moved to a different path \System\Data\RP_Patches.zip
+ Improved: For touch devices the Search Box is hidden by default
+ Fixed: Crash when \patches\ folder was empty



*** Other Important Stuff ***
Feel free to post RP+ v2.4 on forums or everywhere you like, I want just kindly ask you to include the warning message below which is important for the survivor of the project:

[quote]
Warning: If you like this software then support RP+ with a donation.
http://www.symbian-toys.com/rompatcherplus.aspx
[/quote]


Regards,
Marco.


Thanks to:
- ZoRn for the original RomPatcher idea.
- FCA00000 for its brilliant brain.
- wadowice, templove, bugb, abgnokia, leftup, CODeRUS, Leonapapa, PNHT and others, for their contribution to the underground Symbian scene, keep up with the good job!
- megaexer for svg icon.
